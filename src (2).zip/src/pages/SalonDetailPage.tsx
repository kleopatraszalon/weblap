import React, { useEffect, useState } from "react";
import { useParams, Link, Navigate } from "react-router-dom";
import { getPublicSalons, PublicSalon } from "../apiClient";

const ALTEGIO_WIDGETS: Record<string, string> = {
  "budapest-ix": "https://w529306.alteg.io/widgetJS", // Mester u. 1.
  "budapest-viii": "https://w197493.alteg.io/widgetJS", // Rákóczi u. 63.
  "budapest-xii": "https://w206438.alteg.io/widgetJS", // Krisztina krt. 23. (Buda)
  "budapest-xiii": "https://w206416.alteg.io/widgetJS", // Visegrádi u. 3. (Visi)
  eger: "https://w206809.alteg.io/widgetJS",
  gyongyos: "https://w207008.alteg.io/widgetJS",
  salgotarjan: "https://w206818.alteg.io/widgetJS",
};

const DEFAULT_WIDGET_SRC = "https://w714308.alteg.io/widgetJS"; // központi – minden szalon egyben

export const SalonDetailPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [salons, setSalons] = useState<PublicSalon[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    getPublicSalons()
      .then(setSalons)
      .catch((err) => {
        console.error(err);
        setError("Nem sikerült betölteni a szalonokat.");
      });
  }, []);

  const salon = salons?.find((s) => s.slug === slug) ?? null;

  // Altegio widget betöltése a megfelelő szalonhoz
  useEffect(() => {
    if (!salon) return;

    const widgetSrc = ALTEGIO_WIDGETS[salon.slug] ?? DEFAULT_WIDGET_SRC;

    // ha már betöltöttük ezt a scriptet, ne töltsük újra
    const existing = document.querySelector<HTMLScriptElement>(
      `script[src="${widgetSrc}"]`
    );
    if (existing) {
      return;
    }

    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = widgetSrc;
    script.async = true;
    script.charset = "UTF-8";
    document.body.appendChild(script);

    // nem töröljük unmountnál, maradhat globálisan
  }, [salon]);

  if (error) {
    return (
      <main className="section">
        <div className="container">
          <p className="form-msg form-msg--error">{error}</p>
        </div>
      </main>
    );
  }

  if (!salons) {
    return (
      <main className="section">
        <div className="container">
          <p>Szalonadatok betöltése...</p>
        </div>
      </main>
    );
  }

  if (!salon) {
    return <Navigate to="/salons" replace />;
  }

  const mapQuery = `${salon.city_label} ${salon.address ?? ""}`;
  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
    mapQuery
  )}`;
  const mapEmbedUrl = `https://www.google.com/maps?q=${encodeURIComponent(
    mapQuery
  )}&output=embed`;

  // Szalon kép elérési útja – ha nincs külön kép, a közös szalonok.jpg-t használjuk
  const SALON_IMAGES: Record<string, string> = {
    "budapest-ix": "/images/salon-budapest-ix.jpg",
    "budapest-viii": "/images/salon-budapest-viii.jpg",
    "budapest-xii": "/images/salon-budapest-xii.jpg",
    "budapest-xiii": "/images/salon-budapest-xiii.jpg",
    eger: "/images/salon-eger.jpg",
    gyongyos: "/images/salon-gyongyos.jpg",
    salgotarjan: "/images/salon-salgotarjan.jpg",
  };

  const salonImageSrc = SALON_IMAGES[salon.slug] ?? "/images/szalonok.jpg";

  return (
    <main>
      <section className="page-hero page-hero--salons">
        <div className="page-hero__image-wrap">
          <img
            src={salonImageSrc}
            alt={salon.city_label}
            className="page-hero__image"
          />
          <div className="page-hero__image-overlay" />
        </div>
        <div className="container page-hero__content page-hero__content--center">
          <p className="section-eyebrow">Szalonjaink</p>
          <h1>
            {salon.city_label} – {salon.address}
          </h1>
          <p className="hero-lead hero-lead--narrow">
            Ebben a Kleopátra Szépségszalonban is komplett szépségápolási
            szolgáltatásokat kínálunk: fodrászat, kozmetika, kéz- és lábápolás,
            masszázs és további kezelések várnak modern, egységes környezetben.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container grid-two">
          <article className="card">
            <h2 className="card-title">Alapadatok</h2>
            <ul className="info-list">
              <li>
                <strong>Szalon neve:</strong> {salon.city_label}
              </li>
              {salon.address && (
                <li>
                  <strong>Cím:</strong> {salon.address}
                </li>
              )}
              <li>
                <strong>Szolgáltatások:</strong> fodrászat, kozmetika, kéz- és
                lábápolás, masszázs, szolárium (helyszínenként eltérhet)
              </li>
              <li>
                <strong>Fizetési módok:</strong> készpénz, bankkártya,
                SZÉP-kártya
              </li>
            </ul>
          </article>
          <article className="card">
            <h2 className="card-title">Időpontfoglalás</h2>
            <p className="card-text">
              Időpontot foglalhatsz online a lenti foglalási widgeten keresztül,
              mobilalkalmazásunkból vagy telefonon. Akár bejelentkezés nélkül is
              betérhetsz, kollégáink a lehető legrövidebb időn belül fogadnak.
            </p>
            <div className="salon-booking-widget">
              {/* Az Altegio foglalási widget scriptje betöltődik a háttérben
                  (a megfelelő szalonhoz tartozó URL-lel). */}
            </div>
            <Link className="btn btn-outline" to="/salons">
              Vissza a szalonlistához
            </Link>
          </article>
        </div>
      </section>

      <section className="section section--salon-extra">
        <div className="container grid-two">
          <article className="card card--map">
            <h2 className="card-title">Térkép és megközelítés</h2>
            <div className="salon-map">
              <iframe
                src={mapEmbedUrl}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                aria-label={salon.city_label}
                title={salon.city_label}
              ></iframe>
            </div>
            <a
              href={mapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="btn btn-primary btn-primary--magenta"
            >
              Megnyitás a térképen
            </a>
          </article>
          <article className="card">
            <h2 className="card-title">Hasznos tudnivalók</h2>
            <p className="card-text">
              Szalonjaink könnyen megközelíthetők tömegközlekedéssel és
              gépkocsival is. A pontos parkolási lehetőségeket és aktuális
              nyitvatartást a foglalási widgetben, illetve a visszaigazoló
              e-mailben is megtalálod.
            </p>
            <p className="card-text">
              Ha speciális kérésed van (pl. kedvenc fodrász, kozmetikus vagy
              időpontegyeztetés), kérjük, jelezd a megjegyzésben vagy telefonon.
            </p>
          </article>
        </div>
      </section>
    </main>
  );
};
