import { Header as HeaderComponent } from "./components/Header";

export const Header = HeaderComponent;
export default HeaderComponent;
