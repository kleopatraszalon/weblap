// src/App.tsx
import React, { useEffect, useMemo } from "react";
import { MemoryRouter, Routes, Route } from "react-router-dom";
import { Header } from "./components/Header";
import { HomePage } from "./pages/HomePage";
import { SalonsPage } from "./pages/SalonsPage";
import { SalonDetailPage } from "./pages/SalonDetailPage";
import { ServicesPage } from "./pages/ServicesPage";
import { PriceListPage } from "./pages/PriceListPage";
import { LoyaltyPage } from "./pages/LoyaltyPage";
import { FranchisePage } from "./pages/FranchisePage";
import { CareerPage } from "./pages/CareerPage";
import { TrainingPage } from "./pages/TrainingPage";
import { AboutPage } from "./pages/AboutPage";
import { ContactPage } from "./pages/ContactPage";
import { WebshopPage } from "./pages/WebshopPage";
import { WebshopProductDetailPage } from "./pages/WebshopProductDetailPage";

const App: React.FC = () => {
  // 1) Eredeti path elmentése (pl. "/webshop", "/about")
  const initialPath = useMemo(() => {
    if (typeof window === "undefined") return "/";
    const path = window.location.pathname || "/";
    return path;
  }, []);

  // 2) URL visszaírása gyökérre, hogy a címsorban mindig csak "/" legyen
  useEffect(() => {
    if (typeof window !== "undefined" && window.location.pathname !== "/") {
      window.history.replaceState({}, "", "/");
    }
  }, []);

  return (
    <MemoryRouter initialEntries={[initialPath]}>
      {/* ide jön, ami eddig is a BrowserRouter-ben volt */}
      {/* pl.: <Header /> stb. */}
      <Header />

      <Routes>
        {/* A GYÖKÉREN TOVÁBBRA IS A HOME LEGYEN */}
        <Route path="/" element={<HomePage />} />

        {/* Webshop oldal, de ez csak "belső" útvonal, URL-t nem fogja átírni */}
        <Route path="/webshop" element={<WebshopPage />} />

        {/* Termék részletek – ez az, amire a képre kattintás visz */}
        <Route
          path="/webshop/:productId"
          element={<WebshopProductDetailPage />}
        />

        {/* A többi oldal maradhat, ahogy volt: */}
        <Route path="/salons" element={<SalonsPage />} />
        <Route path="/salons/:id" element={<SalonDetailPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/prices" element={<PriceListPage />} />
        <Route path="/loyalty" element={<LoyaltyPage />} />
        <Route path="/franchise" element={<FranchisePage />} />
        <Route path="/career" element={<CareerPage />} />
        <Route path="/training" element={<TrainingPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />

        {/* 404 esetén menjünk vissza Home-ra (belsőleg) */}
        <Route path="*" element={<HomePage />} />
      </Routes>
    </MemoryRouter>
  );
};

export default App;

