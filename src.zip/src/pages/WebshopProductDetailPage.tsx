// src/pages/WebshopProductDetailPage.tsx
import React, { useEffect, useState } from "react";
import { Link, useLocation, useNavigate, useParams } from "react-router-dom";

// Ugyanaz a típus, mint a WebshopPage-ben
type Product = {
  id: string;
  name: string;
  retail_price_gross?: number | string | null;
  sale_price?: number | string | null;
  image_url?: string | null;
  web_description?: string | null;
  is_retail?: boolean | null;
  web_is_visible?: boolean | null;
};

type Review = {
  id: string;
  rating: number;
  text: string;
  authorName: string;
  createdAt: string;
};

const API_BASE =
  (import.meta as any).env?.VITE_API_BASE?.replace(/\/$/, "") ||
  "http://localhost:5000/api";

const API_ROOT = API_BASE.replace(/\/api$/, "");

function buildImageUrl(imageUrl?: string | null): string | undefined {
  if (!imageUrl) return undefined;

  // Ha teljes URL, akkor nem piszkáljuk
  if (/^https?:\/\//i.test(imageUrl)) {
    return imageUrl;
  }

  const cleaned = imageUrl.replace(/^\/+/, "");
  return `${API_ROOT}/${cleaned}`;
}

export const WebshopProductDetailPage: React.FC = () => {
  const { productId } = useParams<{ productId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const state = location.state as { product?: Product } | null;

  const product = state?.product ?? null;

  const [reviews, setReviews] = useState<Review[]>([]);
  const [rating, setRating] = useState<number>(5);
  const [text, setText] = useState<string>("");
  const [authorName, setAuthorName] = useState<string>("");

  // Vélemények betöltése localStorage-ből
  useEffect(() => {
    if (!product) return;

    const storageKey = `webshop_reviews_${product.id}`;
    try {
      const raw = window.localStorage.getItem(storageKey);
      if (raw) {
        const parsed = JSON.parse(raw) as Review[];
        if (Array.isArray(parsed)) {
          setReviews(parsed);
        }
      }
    } catch (err) {
      console.error(
        "Nem sikerült beolvasni a véleményeket a localStorage-ből:",
        err
      );
    }
  }, [product]);

  const persistReviews = (productIdForKey: string, list: Review[]) => {
    try {
      const storageKey = `webshop_reviews_${productIdForKey}`;
      window.localStorage.setItem(storageKey, JSON.stringify(list));
    } catch (err) {
      console.error(
        "Nem sikerült elmenteni a véleményeket a localStorage-be:",
        err
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!product) return;

    const trimmedText = text.trim();
    if (!trimmedText) {
      return;
    }

    const newReview: Review = {
      id: `${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      rating,
      text: trimmedText,
      authorName: authorName.trim() || "Vendég",
      createdAt: new Date().toISOString(),
    };

    const next = [newReview, ...reviews];
    setReviews(next);
    persistReviews(product.id, next);

    // Form reset
    setRating(5);
    setText("");
    setAuthorName("");
  };

  if (!product) {
    return (
      <main className="page">
        <section className="section">
          <div className="container">
            <p>
              A termék adatai közvetlen URL-ből nem érhetők el. Kérlek, térj
              vissza a{" "}
              <Link to="/" className="link">
                webshop listához
              </Link>
              , és onnan nyisd meg a részleteket.
            </p>

            <button
              type="button"
              className="btn btn-secondary"
              onClick={() => navigate(-1)}
            >
              Vissza
            </button>
          </div>
        </section>
      </main>
    );
  }

  const imageSrc = buildImageUrl(product.image_url);

  const rawPrice =
    product.sale_price ?? product.retail_price_gross ?? 0;

  const numericPrice =
    typeof rawPrice === "string"
      ? parseFloat(rawPrice.replace(",", "."))
      : rawPrice ?? 0;

  const formattedPrice =
    !numericPrice || Number.isNaN(numericPrice)
      ? ""
      : `${numericPrice.toLocaleString("hu-HU")} Ft`;

  return (
    <main className="page">
      <section className="section">
        <div className="container webshop-product-detail">
          <div className="webshop-product-detail__top">
            <div className="webshop-product-detail__image">
              {imageSrc ? (
                <img src={imageSrc} alt={product.name} />
              ) : (
                <div className="webshop-product-detail__image--placeholder">
                  Nincs kép ehhez a termékhez.
                </div>
              )}
            </div>

            <div className="webshop-product-detail__info">
              <p className="section-eyebrow">Webshop termék</p>
              <h1 className="hero-title hero-title--tight">
                {product.name}
              </h1>

              {product.web_description && (
                <p className="hero-lead hero-lead--narrow">
                  {product.web_description}
                </p>
              )}

              {formattedPrice && (
                <p className="webshop-product-detail__price">
                  {formattedPrice}
                </p>
              )}

              <div className="webshop-product-detail__actions">
                <Link to="/" className="btn btn-secondary">
                  Vissza a webshophoz
                </Link>
              </div>
            </div>
          </div>

          <div className="webshop-product-detail__reviews">
            <h2>Vélemények</h2>

            {reviews.length === 0 && (
              <p>
                Még nem érkezett vélemény ehhez a termékhez. Légy te az első!
              </p>
            )}

            {reviews.length > 0 && (
              <ul className="webshop-review-list">
                {reviews.map((review) => (
                  <li key={review.id} className="webshop-review">
                    <div className="webshop-review__header">
                      <div className="webshop-review__rating">
                        {Array.from({ length: 5 }, (_, i) => {
                          const star = i + 1;
                          const filled = star <= review.rating;
                          return (
                            <span
                              key={star}
                              className={
                                filled ? "star star--filled" : "star"
                              }
                            >
                              {filled ? "★" : "☆"}
                            </span>
                          );
                        })}
                      </div>
                      <span className="webshop-review__author">
                        {review.authorName || "Vendég"}
                      </span>
                      <span className="webshop-review__date">
                        {new Date(review.createdAt).toLocaleDateString(
                          "hu-HU"
                        )}
                      </span>
                    </div>
                    <p className="webshop-review__text">{review.text}</p>
                  </li>
                ))}
              </ul>
            )}

            <div className="webshop-review-form">
              <h3>Írj véleményt a termékről</h3>

              <form onSubmit={handleSubmit}>
                <div className="form-row">
                  <label htmlFor="review-author">Név (nem kötelező)</label>
                  <input
                    id="review-author"
                    type="text"
                    value={authorName}
                    onChange={(e) => setAuthorName(e.target.value)}
                    placeholder="Add meg a neved (opcionális)"
                  />
                </div>

                <div className="form-row">
                  <span>Értékelés</span>
                  <div className="rating-input">
                    {Array.from({ length: 5 }, (_, i) => {
                      const star = i + 1;
                      const filled = star <= rating;
                      return (
                        <button
                          key={star}
                          type="button"
                          className={
                            filled
                              ? "star star--interactive star--filled"
                              : "star star--interactive"
                          }
                          onClick={() => setRating(star)}
                          aria-label={`${star} csillag`}
                        >
                          {filled ? "★" : "☆"}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div className="form-row">
                  <label htmlFor="review-text">Vélemény</label>
                  <textarea
                    id="review-text"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    rows={4}
                    required
                    placeholder="Írd le, mit tapasztaltál a termékkel kapcsolatban…"
                  />
                </div>

                <button
                  type="submit"
                  className="btn btn-primary btn-primary--magenta"
                >
                  Vélemény elküldése
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

export default WebshopProductDetailPage;
