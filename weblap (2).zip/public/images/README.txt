Ide másold be a logót (Logo.jpeg) és a hero képeket (images_1.webp ... images_4.webp).
