export function MelegollosPage() {
  return (
    <main>
      <h1>Melegollós hajkezelés</h1>
    </main>
  );
}

export default MelegollosPage;
